# -*- coding: utf-8 -*-

"""Top-level package for tsk-mgr."""

__author__ = """Markus Zoeller"""
__email__ = 'bogus@nope.com'
__version__ = '0.1.0'
