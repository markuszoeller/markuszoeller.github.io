=======
History
=======

0.1.0 (2017-12-10)
------------------

* First release on PyPI.
