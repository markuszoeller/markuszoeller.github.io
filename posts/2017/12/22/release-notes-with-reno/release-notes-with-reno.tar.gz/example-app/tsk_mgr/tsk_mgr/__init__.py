# -*- coding: utf-8 -*-

"""Top-level package for tsk-mgr."""

__version__ = '0.1.0'
