=====
Usage
=====

To use tsk-mgr in a project::

    import tsk_mgr
